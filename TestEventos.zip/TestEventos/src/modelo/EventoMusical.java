package modelo;

import java.io.Serializable;
import java.time.LocalDate;
import servicio.CSVSerializable;

public class EventoMusical extends Evento implements Comparable<Evento>, CSVSerializable, Serializable {
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return super.toString() + ", artista=" + artista + ", genero=" + genero;
    }
    
    @Override
    public int compareTo(Evento e) {
        return getFecha().compareTo(e.getFecha());
    }

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;
    }

    @Override
    public String toHeader() {
        return "id,nombre,fecha,artista,genero";
    }
    
    public static EventoMusical fromCSV(String eventoMusicalCSV) {
        String[] valores = eventoMusicalCSV.split(",");
        return new EventoMusical(Integer.parseInt(valores[0]), 
                valores[1], 
                LocalDate.parse(valores[2]), 
                valores[3], 
                GeneroMusical.valueOf(valores[4]));
    }
    
}
