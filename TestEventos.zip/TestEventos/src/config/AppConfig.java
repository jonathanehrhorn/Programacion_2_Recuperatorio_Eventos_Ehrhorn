package config;

public class AppConfig {

    public static final String PATH_ARCHIVOS = "src/data/";
    public static final String PATH_SER = PATH_ARCHIVOS + "eventos.dat";
    public static final String PATH_CSV = PATH_ARCHIVOS + "eventos.csv";

}
