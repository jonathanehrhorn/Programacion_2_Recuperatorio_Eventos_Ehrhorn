package servicio;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/*
▪ Agregar, eliminar, obtener y limpiar elementos.
▪ Ordenar por criterio natural y personalizado.
▪ Filtrar elementos según un criterio dado.
▪ Guardar y cargar elementos desde archivos binarios.
▪ Guardar y cargar elementos en formato CSV.
▪ Mostrar todos los elementos en consola.
*/

public interface Gestionable <T extends CSVSerializable> {

    void agregar(T item);
    T obtener(int indice);
    void eliminar(int indice);
    void mostrarTodos();
    List<T> filtrar(Predicate<? super T> criterio);
    void ordenar();
    void ordenar(Comparator<T> comparador);
    void guardarEnBinario(String path);
    void cargarDesdeBinario(String path);
    void guardarEnCSV(String path);
    void cargarDesdeCSV(String path, Function<String, T> funcion);
    void paraCadaElemento(Consumer<? super T> accion);

}
