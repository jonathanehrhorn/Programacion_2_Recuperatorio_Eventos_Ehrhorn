package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorEventos<T extends CSVSerializable> implements Gestionable<T> {
    List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("Usted no puede ingresar un null");
        }
        lista.add(item);
    }

    private int tamanio() {
        return lista.size();
    } 
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("Elemento menor a 0 o mayor al tamanio de la lista");
        }
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return lista.get(indice);        
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        lista.remove(indice);
    }

    @Override
    public void mostrarTodos() {
        for (T item : lista) {
            System.out.println(item);
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T item : lista) {
            if (criterio.test(item)) {
                aux.add(item);
            }
        }
        return aux;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    }

    @Override
    public void guardarEnBinario(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            lista = (List<T>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,fecha,artista,genero\n");
            for (T item : lista) {
                bw.write(item.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en el archivo");
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                lista.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en el archivo");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : lista) {
            accion.accept(item);
        }
    }    
    
}
